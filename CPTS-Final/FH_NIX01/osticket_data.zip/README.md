## Guide: Osticket in Production

## Status
**Complete**  


## Overview
**Type**: Dockerfile
**Vhost**: osticketapp.trilocor.local
**Version**: Tested on Docker version 20.10.8+dfsg1 
**Admin Username**: Administrator
**Admin Password**: ************


## Push to prod
chmod +x build.sh & run ./build.sh to configure osticket in prod
